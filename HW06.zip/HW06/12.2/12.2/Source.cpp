#include < iostream>
#include <string>
#include <vector>

using namespace std;

template<typename T>
int linearSearch(const T list[], T key, int arraySize)
{
	// goes through each element in the array
	for (int x = 0; x < arraySize; x++)
	{
		// checks to see if the element specified is in the array
		if (key == list[x])
			return x;
	}
	return -1;
}

int main()
{
	int size = 8;
	// creates an array if ints
	int list[] = { 1,4,4,2,5,-3,6,2 };
	// creates an array of strings
	string list2[] = { "a","b","c","d","e","f","h","I" };
	// creates an array of doubles
	double list3[] = { 1.1,2.2,3.3,4.4,5.5,6.6,7.7,8.8 };

	// calls the function and looks for 4 in list
	linearSearch(list, 4, size);

	// creates a string to look for in list2
	 string find = "c";
	 // call the function to search for "c" in list2
	 linearSearch(list2, find, size);

	// calls the function to search for "1.3" in list3
	 linearSearch(list3, 1.3, size);


	
}