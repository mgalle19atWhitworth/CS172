#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>

using namespace std;

template <typename T>
void shuffle(vector<T> & v)
{
	int x = 0;
	// makes x the size of the vector
	x= v.size();

	// creates a variable to swap number with
	T z;
	// creates a variable that can randomize the numbers
	int r = 0;
	// for loop goes through all the numbers in the array
	for (int y = 0; y < x; y++)
	{
		// makes r random depending on the number in the loop 
		r = rand() % (y + 1);
		// make "z" become what was in the orglinal vector "v"
		z = v[y];
		// makes "v" equal what "r" equals
		v[y] = v[r];
		// puts the number in z into the vector 
		v[r] = z;
	}
}

int main()
{
	// creates a vector named "v1"
	vector <int> v1(10);
	// lets the user enter in ten numbers 
	cout << "Please enter 10 numbers: " << endl;
	for (int x = 0; x < 10; x++)
	{
		cin >> v1[x];
	}
	cout << endl;
	// shuffles the numbers
	shuffle(v1);
	
	// outputs the numbers the user inputed shuffled
	cout << "Your numbers shuffled: " << endl;
	for (int x = 0; x < 10; x++)
	{
		cout << v1[x];
		cout << endl;
	}

	return 0;
}