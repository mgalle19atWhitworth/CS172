#include <iostream>
#include <string>
#include <vector>
using namespace std;


template<typename T>
bool isSorted(const T list[], int size)
{
	// The for loop goes through each of the numbers
	// (size-1) makes sure the loop doesn't look at numbers that aren't in the array
	for (int x = 1;x < size-1; x++)
	{
		// The IF checks the first number and compares it to the next number and returns false if the first one is bigger
		if (list[x] > list[x + 1])
		{
			cout << "False\n";
			return false;
		}	
		
	}
	cout << "True\n";
	return true;
}



int main()
{
	// creates an array of ints
	int array[3]{ 1,2,3 };
	// creates an array of doubles
	double array2[3]{ 1.1, 6.1, 3.2 };
	// creates an array of strings
	string array3[3]{ "A","B","C" };
	// the size of the arrays
	int size = 3;
// Runs the function for all of the arrays
	isSorted(array, size);
	isSorted(array2, size);
	isSorted(array3, size);

}