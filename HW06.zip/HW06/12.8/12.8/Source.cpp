#include <iostream>
#include <string>
#include "Vector.h"
using namespace std;

int main()
{
	// creates a vector
	NewVector<int> V;
// adds numbers to the vector
	V.push_back(0);
	V.push_back(1);
	V.push_back(2);
	V.push_back(3);
	// creates another vector and adds numbers
	NewVector<int> V2;
	V2.push_back(10);
	V2.push_back(20);
	V2.push_back(30);

	// swaps the first vectors numbers with the secound vectors numbers
	V.swap(V2);

	// outputs the amount of numbers in V
	cout << V.size2() << endl;
	// outputs the number at postion 2 in V
	cout << V.at(2) << endl;
	// Checks to see if V is empty 
	cout << V.empty()<< endl;
	// Clears V2
		V2.clear();
	


	return 0;
}