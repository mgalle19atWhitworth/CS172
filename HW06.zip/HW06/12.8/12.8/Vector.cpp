#include <iostream>
#include <string>
#include "Vector.h"

// Creates an empty vector
template<typename T>
NewVector<T> ::NewVector()
{
	size = 0;
}

template<typename T>
void NewVector<T> ::push_back(T y)
{
	// puts the numbers in the vector
	x[size++] = variable;
}


template<typename T>
void NewVector<T> :: pop_back()
{
	// removes the last number in vector
	x[size--]
	return x;
}

template<typename T>
int NewVector<T> ::size2()
{
	// return the size of the vector
	return size;
}

template<typename T>
bool NewVector<T> ::empty()
{
	// return true if the vectors empty
	if (size == 0) {
		return true;
	}
	// return false if there are numbers in the vector
	return false;
}

template<typename T>
void NewVector<T> ::clear()
{
	// clears all the numbers from the vector 
	size = 0;
}

template<typename T>
T NewVector<T> ::at(int i)
{
	// returns the number at the given location
	return x[i];
}


// swaps two vectors numbers
template<typename T>
void NewVector<T> ::swap(NewVector v2)
{
	T = temp;
	int tsize = v2.size();

	for (int x = 0; x < v2.size(); x++)
	{
		temp[x] = NewVector[x];
		NewVector[x] = v2.at[x];
		v2[x] = temp[x];
	}	
}