#ifndef Vector_H_
#define Vecotor_H_

// NewVector is the name of the class to make vectors
template <typename T>
class NewVector {

private:
	// creates an array 
	T x[50];
	// The size of the vector
	int size;
public: 
	// non-arugment constructor
	// constructs an empty vector that can take any element type
	NewVector();
	// Adds the numbers to the vector
	void push_back(T x);
	// removes the last number from the vector
	void pop_back();
	// Returns the amount of numbers in the vector
	int size2();
	// returns true if the vecotr is empty and false if its not empty
	bool empty();
	// removes all the numbers from the vector
	void clear();
	// swaps the numbers in one vector into another vector
	void swap(NewVector v2);
	// Returns the number at the specified location 
	T at(int i);

};


#endif 
